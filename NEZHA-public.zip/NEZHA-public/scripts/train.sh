#!/bin/bash
[ -z "${OMPI_COMM_WORLD_SIZE}" ] && OMPI_COMM_WORLD_SIZE=1
[ -z "${OMPI_COMM_WORLD_RANK}" ] && OMPI_COMM_WORLD_RANK=0
[ -z "${n_gpu}" ] && n_gpu=$(nvidia-smi -L | wc -l)
[ -z "${MASTER_IP}" ] && MASTER_IP=127.0.0.1
[ -z "${MASTER_PORT}" ] && MASTER_PORT=10087

model_list=("Qwen/Qwen3-0.6B/" "LLM-Research/Llama-3.2-1B/")
LR=1e-5
DOCID_NUM="512,512,512"
INDEX_FILE="code3_dict.json"

BATCH_SIZE=256

data_list=("beauty" "games")
# data_list=("yelp")
# DATASET="beauty" 
for MODEL in ${model_list[@]}
do 
for DATASET in ${data_list[@]}
do
OUTPUT_DIR="./$DATASET/$MODEL/$(date '+%Y%m%d_%H%M%S')"
MODEL_NAME="./$MODEL"
#        --use_mtp \   
args="--base_model=$MODEL_NAME \
    --docid_num=$DOCID_NUM \
    --padding_side="right" \
    --only_train_response \
    --data_path="./data"\
    --dataset=$DATASET \
    --output_dir=$OUTPUT_DIR \
    --epochs 20 \
    --index_file $INDEX_FILE\
    --per_device_batch_size=${BATCH_SIZE} \
    --gradient_accumulation_steps=2 \
    --bf16 \
    --learning_rate=${LR} \
    --weight_decay=0.00001 \
    --save_and_eval_steps=50\
    --metric_for_best_model="loss" \
    --report_to="none" \
    --gradient_checkpointing \
    --deepspeed=./config/ds_z2_bf16.json"


python -m torch.distributed.launch \
    --nnodes=$OMPI_COMM_WORLD_SIZE \
    --node_rank=$OMPI_COMM_WORLD_RANK \
    --nproc_per_node=$n_gpu \
    --master_addr=$MASTER_IP \
    --master_port=$MASTER_PORT \
    finetune.py ${args}
done
done