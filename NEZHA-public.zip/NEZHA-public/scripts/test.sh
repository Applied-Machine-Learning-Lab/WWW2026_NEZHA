
#!/bin/bash
set +x
export CUDA_DEVICE_MAX_CONNECTIONS=1
export RANK=0
export WORLD_SIZE=1



DOCID_NUM="512,512,512"
INDEX_FILE="code3_dict.json"

BATCH_SIZE=16
NUM_BEAMS=10


DATASET=beauty
ckpt_list=("Qwen/Qwen3-0.6B/")


RESULTS_FILE="./log/$DATASET/"
for CKPT in ${ckpt_list[@]}
do
MODEL_NAME="./$DATASET/$CKPT"
args="--base_model=$MODEL_NAME \
    --docid_num=$DOCID_NUM \
    --padding_side=left \
    --data_path="./data"\
    --dataset=$DATASET \
    --load_from_docid_checkpoint \
    --bf16 \
    --model_max_length=1024 \
    --index_file $INDEX_FILE\
    --test_batch_size=$BATCH_SIZE \
    --num_beams=$NUM_BEAMS\
    --results_file $RESULTS_FILE "

CUDA_VISIBLE_DEVICES=7 python test.py ${args}

done