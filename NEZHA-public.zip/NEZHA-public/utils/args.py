from dataclasses import dataclass, field
from typing import Optional

import transformers
from transformers.utils import logging


logger = logging.get_logger(__name__)



def parse_global_args(parser):
    parser.add_argument("--verbose", action="store_true", help='whether or not print the time costs')
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--output_dir", type=str, help="The output directory")
    parser.add_argument("--base_model", type=str, help="model path")  # Model path, model_name_or_path
    # parser.add_argument("--target_model", type=str, help="lora weights of the target model")

    return parser


def parse_dataset_args(parser):
    parser.add_argument("--data_path", type=str, help="data directory")
    parser.add_argument("--dataset", type=str, default="games", help="Dataset name")
    parser.add_argument("--index_file", type=str, default="code3.json", help="the item indices file")
    parser.add_argument("--docid_num", type=str, default="512,512,512")
    # arguments related to sequential task
    parser.add_argument("--max_his_len", type=int, default=20,
                        help="the max number of items in history sequence, -1 means no limit")
    parser.add_argument("--add_prefix", action="store_true", default=False,
                        help="whether add sequential prefix in history")
    parser.add_argument("--his_sep", type=str, default=", ", help="The separator used for history")
    parser.add_argument("--only_train_response", action="store_true", default=False,
                        help="whether only train on responses")
    parser.add_argument("--train_prompt_sample_num", type=str, default="1",
                        help="the number of sampling prompts for each task")
    parser.add_argument("--train_data_sample_num", type=str, default="-1",
                        help="the number of sampling prompts for each task")
    # arguments related for evaluation
    parser.add_argument("--valid_prompt_id", type=int, default=0,
                        help="The prompt used for validation")
    parser.add_argument("--sample_valid", action="store_true", default=True,
                        help="use sampled prompt for validation")
    parser.add_argument("--valid_prompt_sample_num", type=int, default=2,
                        help="the number of sampling validation sequential recommendation prompts")

    return parser

def parse_train_args(parser):

    parser.add_argument("--optim", type=str, default="adamw_torch", help='The name of the optimizer')
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--local-rank", type=int, default=0)
    parser.add_argument("--learning_rate", type=float, default=1e-4)
    parser.add_argument("--per_device_batch_size", type=int, default=8)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=2)
    parser.add_argument("--logging_step", type=int, default=10)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--report_to", type=str, default="none")
    parser.add_argument("--resume_from_checkpoint", type=str, default=None, help="either training checkpoint or final adapter")
    parser.add_argument("--metric_for_best_model", type=str, default="loss")
    parser.add_argument("--warmup_ratio", type=float, default=0.01)
    parser.add_argument("--lr_scheduler_type", type=str, default="cosine")
    parser.add_argument("--save_and_eval_strategy", type=str, default="steps")
    parser.add_argument("--save_and_eval_steps", type=int, default=200)
    parser.add_argument("--gradient_checkpointing",  action="store_true", default=False)
    parser.add_argument("--fp16",  action="store_true", default=False)
    parser.add_argument("--deepspeed", type=str, default="./config/ds_z2_bf16.json")

    parser.add_argument("--subseq", action="store_true", help="whether or not use subsequence in training")
    parser.add_argument("--random_seed", type=int, default=42)
    return parser

def parse_test_args(parser):

    parser.add_argument("--ckpt_path", type=str, help="The checkpoint path")
    parser.add_argument("--filter_items", action="store_true", help="whether filter illegal items")

    parser.add_argument("--results_file", type=str, help="result output path")

    parser.add_argument("--test_batch_size", type=int, default=1)
    parser.add_argument("--num_beams", type=int, default=20)
    parser.add_argument("--sample_num", type=int, default=-1,
                        help="test sample number, -1 represents using all test data")
    parser.add_argument("--gpu_id", type=int, default=0,
                        help="GPU ID when testing with single GPU")
    parser.add_argument("--test_prompt_ids", type=str, default="0",
                        help="test prompt ids, separate by comma. 'all' represents using all")
    parser.add_argument("--metrics", type=str, default="hit@1,hit@5,hit@10,ndcg@5,ndcg@10",
                        help="test metrics, separate by comma")
    parser.add_argument("--test_task", type=str, default="SeqRec")
    parser.add_argument("--max_new_token", type=int, default=4)

    return parser

def parse_model_args(parser):
    parser.add_argument("--use_mtp", action="store_true", default=False)
    parser.add_argument("--cache_dir", type=str, default=None)
    parser.add_argument("--use_flash_attn", action="store_false",default=True)
    parser.add_argument("--load_from_docid_checkpoint", action="store_true",default=False)
    parser.add_argument("--padding_side", type=str, default="right")
    parser.add_argument("--model_max_length", type=int, default=1024)
    parser.add_argument("--bf16", action="store_true", default=False)
    return parser

def parse_inference_args(parser):
    parser.add_argument("--draft_model", type=str)
    parser.add_argument("--target_base_model", type=str)
    parser.add_argument("--target_ckpt_path", type=str)
    parser.add_argument("--draft_model_name", type=str)
    parser.add_argument("--target_model_name", type=str)
    parser.add_argument("--gamma", default=4, type=int)
    parser.add_argument("--run_beam_sizes", type=str)
    parser.add_argument("--draft_beam_size", type=int)
    parser.add_argument("--prefixAllowed", default=True, action="store_true")
    parser.add_argument("--do_sample", default=False, action="store_true")
    parser.add_argument("--temperature", type=float, default=1)
    parser.add_argument("--metrics", type=str, default="hit@1,hit@5,hit@10,hit@50,hit@100,hit@500,ndcg@5,ndcg@10",
                        help="test metrics, separate by comma")
    parser.add_argument("--L", type=int, default=0)
    parser.add_argument("--R", type=int, default=None)
    return parser




# @dataclass
# class InferArguments:
#     infer_batch_size: int = field(default=4, metadata={"help": "Inference batch size"})
#     num_return_sequences: int = field(default=50)
#     top_k: int = field(default=20)
#     top_p: float = field(default=0.3)
#     infer_mode: str = field(default="default")
#     trie_partition: str = field(default="")
#     predict_ctr: int = field(default=0)
