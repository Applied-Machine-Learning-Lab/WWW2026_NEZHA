import os
import json
from typing import Tuple

import torch.nn as nn
from transformers import (
    AutoConfig,
    AutoModelForCausalLM,
    AutoTokenizer,
    GenerationConfig,
    __version__,
)
# from transformers.nebula_hub_utils import NebulaHubUtils
# from transformers.trainer_utils import get_last_checkpoint
from transformers.utils import logging
from openlm_hub import repo_download
from safetensors import safe_open
from functools import partial
from models.hack import ctr_forward, MTP_HEAD, mtp_generate
from torch.utils.data import ConcatDataset
from dataset import SeqRecDataset

logger = logging.get_logger(__name__)


def count_parameters(model: nn.Module) -> Tuple[int, int]:
    r"""
    Returns the number of trainable parameters and number of all parameters in the model.
    """
    trainable_params, all_param = 0, 0
    for param in model.parameters():
        num_params = param.numel()
        # if using DS Zero 3 and the weights are initialized empty
        if num_params == 0 and hasattr(param, "ds_numel"):
            num_params = param.ds_numel

        # Due to the design of 4bit linear layers from bitsandbytes, multiply the number of parameters by 2
        if param.__class__.__name__ == "Params4bit":
            num_params = num_params * 2

        all_param += num_params
        if param.requires_grad:
            trainable_params += num_params

    return trainable_params, all_param


def add_tokens(module, token_size):
    assert isinstance(module, (nn.Linear, nn.Embedding))

    old_weight = module.weight.data
    vocab_size, hidden_dim = old_weight.shape
    print("Old module:\n", module, old_weight.shape)

    if isinstance(module, nn.Linear):
        module = nn.Linear(hidden_dim, token_size, bias=False)
    else:
        module = nn.Embedding(token_size, hidden_dim)
    
    module.weight.data[:vocab_size] = old_weight

    print("New module:\n", module, module.weight.data.shape)
    print("Successfully add {} tokens.".format(module.weight.data.shape[0]-vocab_size))
    
    return module


def load_models_tokenizer(
    args, is_eval=False, model_obj=AutoModelForCausalLM
):
    local_path = args.base_model

    config = AutoConfig.from_pretrained(
        local_path,
        cache_dir=args.cache_dir,
        trust_remote_code=True,
        use_flash_attn=args.use_flash_attn,
        bf16=args.bf16,
        use_cache=is_eval,
    )

    tokenizer = AutoTokenizer.from_pretrained(
        local_path,
        cache_dir=args.cache_dir,
        trust_remote_code=True,
        model_max_length=args.model_max_length,
        padding_side=args.padding_side,
        pad_token="<|endoftext|>",
        eos_token="<|endoftext|>",
    )

    model = model_obj.from_pretrained(
        local_path,
        cache_dir=args.cache_dir,
        trust_remote_code=True,
        config=config,
        device_map = "auto",
        ignore_mismatched_sizes=True
    )
    if is_eval:
        args.device_map = "auto"
        model.generation_config = GenerationConfig.from_pretrained(
            local_path,
            return_dict_in_generate = True,
            output_scores=True,
            pad_token_id=tokenizer.pad_token_id, 
            max_new_tokens=len(args.docid_num),
            do_sample=False,
            num_beams = args.num_beams,
            num_return_sequences = args.num_beams,
            top_k = 20,
            top_p = 0.3,
        )
        model.cuda()

    if args.docid_num is not None:
        if not args.load_from_docid_checkpoint:  # Train
            model.config.docid_num = args.docid_num
            model.config.data_path = os.path.join(args.data_path, args.dataset)
            model.config.old_vocab_size = len(tokenizer)
            new_tokens = [f"<{chr(ord('a') + i)}_{n}>" for i, num in enumerate(args.docid_num) for n in range(num)]
            new_tokens += [f"<sp_{i}>" for i in range(len(args.docid_num))]
            tokenizer.add_tokens(new_tokens)
            model.resize_token_embeddings(len(tokenizer))
            model.config.vocab_size = len(tokenizer)
            offset = [model.config.old_vocab_size] + model.config.docid_num[:-1]
            model.config.offset = [sum(offset[:i+1]) for i in range(len(offset))]
            if args.use_mtp:
                model.forward = partial(ctr_forward, model)
                model.config.max_sid=len(tokenizer)-len(args.docid_num)
                model.config.use_mtp = args.use_mtp
                model.mtp_head = MTP_HEAD(model.config,config.hidden_size)
        else: # Test 
            if args.use_mtp:
                model.forward = partial(ctr_forward, model)
                model.mtp_head = MTP_HEAD(model.config,config.hidden_size).to(model.device)
                model.mtp_generate = partial(mtp_generate, model)
                file_path = local_path+"/model.safetensors"
                with safe_open(file_path, framework="pt", device="cuda:0") as f:
                    state_dict = {}
                    for key in f.keys():
                        if 'mtp' in key:
                            state_dict[key] = f.get_tensor(key)
                model.load_state_dict(state_dict, strict=False)
                model.mtp_head.to(model.device)
    else:
        if args.load_from_docid_checkpoint:
            raise ValueError("When load_from_docid_checkpoint is set to be True, docid_num cant be None.")
    model.config.bos_token_id = tokenizer.bos_token_id
    model.config.eos_token_id = tokenizer.eos_token_id
    model.config.pad_token_id = tokenizer.pad_token_id
    return model, tokenizer


def load_datasets(args):
    train_data = SeqRecDataset(args, mode="train", sample_num=args.train_data_sample_num)
    valid_data = SeqRecDataset(args,"valid",args.valid_prompt_sample_num)

    return train_data, valid_data

def load_test_dataset(args):
    test_data = SeqRecDataset(args, mode="test", sample_num=args.sample_num)

    return test_data

def load_json(file):
    with open(file, 'r') as f:
        data = json.load(f)
    return data

