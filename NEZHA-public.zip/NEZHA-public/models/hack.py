import json
from typing import List, Optional, Tuple, Union, Dict, Any
import numpy
import os
import torch
import torch.nn as nn
from torch.autograd import Function
from torch.nn import BCEWithLogitsLoss, CrossEntropyLoss, MSELoss
from dataclasses import dataclass
from openlm_hub import repo_download
from functools import partial
from transformers.cache_utils import Cache
from transformers.modeling_outputs import (
    BaseModelOutputWithPast,
    CausalLMOutputWithPast,
    # SequenceClassifierOutputWithPast,
    # TokenClassifierOutput,
)


def fixed_cross_entropy(
    source, target, num_items_in_batch: int = None, ignore_index: int = -100,
    weight: torch.Tensor = None
):
    if weight is not None:
        reduction = 'none'
    elif num_items_in_batch is not None:
        reduction = "sum"
    else:
        reduction = "mean"
    loss = torch.nn.functional.cross_entropy(source, target, ignore_index=ignore_index, reduction=reduction)
    if reduction == "sum":
        loss = loss / num_items_in_batch
    elif reduction == "none":
        loss = (loss * weight).sum() / weight.sum()
    return loss



class MTP_HEAD(nn.Module):
    def __init__(self,model_config, hidden_size):
        super().__init__()
        self.max_sid=model_config.max_sid
        self.offset=model_config.offset+[self.max_sid]
        print(self.offset)
        self.docid_num=model_config.docid_num 
        self.vocab_size=model_config.vocab_size
        self.use_mtp=model_config.use_mtp
        self.hidden_size=hidden_size
        self.token_emb_list=nn.ModuleList([nn.Embedding(num, self.hidden_size) for num in self.docid_num]) 
        self.transition = nn.ModuleList([nn.RNNCell(self.hidden_size,self.hidden_size, dtype=torch.bfloat16) for num in self.docid_num]) 
        self.logit_head_list=nn.ModuleList([nn.Linear(self.hidden_size,num,bias=False) for num in self.docid_num])
        self.sparse_tensor = torch.load(model_config.data_path+f'/ava_sid{len(self.docid_num)}.pt')
        self.beam_trie = {0: (self.sparse_tensor%512).unique(),
                            1: (self.sparse_tensor%512**2).unique(),
                            2: self.sparse_tensor.unique()} # Trie for three-digit 
        
    def forward(self, hd, labels): #Forward for training
        # hd: [B,1+L,H]
        # labels: [B,L]
        B, L = labels.shape 
        logits = []
        root_hd = hd[:,0,:] # torch.zeros_like(hd[:,0,:])
        cur_hd = hd[:,1:,:] # B,L,H  
        for i in range(L):
            new_logit=self.logit_head_list[i](root_hd+cur_hd[:,i,:])#torch.cat([root_hd,cur_hd[:,i,:]],-1)
            logits.append(new_logit)
            if i+1<= cur_hd.shape[2]:
                delta = self.token_emb_list[i](labels[:,i]) # B, H 
                root_hd = self.transition[i](delta,root_hd) # root_hd+delta 
                print(f"Step {i}: delta norm:{delta.norm(dim=-1).mean().item(),delta.norm(dim=-1).std().item()},root norm:{root_hd.norm(dim=-1).mean().item(),root_hd.norm(dim=-1).std().item()}")
        return logits
    
    def return_logits(self,logits:List[torch.tensor]):
        lgt_full=[]
        base_shape = list(logits[0].shape)[:-1]
        for idx, lgt in enumerate(logits):
            tmp_logits = torch.full(
                base_shape+ [self.vocab_size], 
                fill_value=-1000.0,
                device=lgt.device,     
                dtype=lgt.dtype         
            )
            
            tmp_logits[..., self.offset[idx]:self.offset[idx]+lgt.shape[-1]] = lgt
            lgt_full.append(tmp_logits.contiguous())  
        return torch.stack(lgt_full,dim=1) # B,3,Voc
    
    def predict(self, hd, topk):  # Predict for infernece 
        if isinstance(topk, int):
            topk = [topk] * len(self.logit_head_list)
        return self._optimized_beam_predict(hd, topk, beam_size=topk[0])


    def _optimized_beam_predict(self, hd, topk=1000, beam_size=1000):
        B, L, H = hd.shape
        device = hd.device
        num_positions = len(self.logit_head_list)
        if isinstance(topk, int):
            topk = [topk] * num_positions# 使用更紧凑的数据结构
        beam_data = {
            'hd': hd[:,0,:].unsqueeze(1),  # (B, 1, H), current hd torch.zeros_like(hd[:,0,:].unsqueeze(1))
            'hd_origin': hd[:,1:,:],
            'logits': torch.zeros(B,1, device=device, dtype=hd.dtype),
            'sequences': torch.zeros(B,1, num_positions, device=device, dtype=torch.long)
        }
        for i, (head, token_emb) in enumerate(zip(self.logit_head_list, self.token_emb_list)):
            beam_data = self._process_beam_step(beam_data, head, token_emb, topk[i], beam_size, i, num_positions)
        
        return beam_data['sequences']+torch.tensor(self.offset[:-1],device=hd.device)[None,:],beam_data['logits']

    def _process_beam_step(self, beam_data, head, token_emb, k, beam_size, step_idx, total_steps):
        """处理单个beam search步骤"""
        B = beam_data['hd'].shape[0]
        current_beam_size = beam_data['hd'].shape[1]
        device = beam_data['hd'].device
        # 计算logits
        logits = head((beam_data['hd_origin'][:,step_idx,:].unsqueeze(1)+beam_data['hd']).view(-1, beam_data['hd'].shape[-1]))
        logits = logits.view(B, current_beam_size, -1)
        log_probs = logits.log_softmax(dim=-1)
        #获取topk
        top_logits, top_indices = torch.topk(log_probs, k=k, dim=-1)
        #计算新的beam scores
        new_logits = (beam_data['logits'].unsqueeze(-1) + top_logits).view(B, -1)
        new_sequences = beam_data['sequences'].unsqueeze(2).repeat(1, 1, k, 1).view(B, -1, total_steps)
        new_sequences[:, :, step_idx] = top_indices.view(B, -1)
        # 选择最佳的beams
        max_beams = min(beam_size, new_logits.shape[1])
        if step_idx<=total_steps-1: # 最后一步做限制
        # # print(f"processing {step_idx} digits")
            new_idx = 0 
            for i in range(total_steps):
                new_idx += new_sequences[:,:,i]*512**i
            logits_null = torch.full_like(new_logits, float('-inf'),device=new_logits.device)
            new_logits = torch.where(torch.isin(new_idx,self.beam_trie[step_idx].to(new_idx.device)),new_logits,logits_null)
    
        selected_logits, selected_idx = torch.topk(new_logits, k=max_beams, dim=1)
        # 计算选中的beam和token索引
        # 构建新的索引历史
        batch_idx = torch.arange(B, device=device).unsqueeze(1).expand(-1, max_beams)
        new_sequences = new_sequences[batch_idx, selected_idx]
        new_logits = selected_logits
        #添加当前步骤的索引
        # 更新hidden state
        if step_idx< total_steps - 1:
            beam_indices = selected_idx // k
            token_indices = selected_idx % k
            selected_hd = beam_data['hd'][batch_idx, beam_indices]
            current_tokens = top_indices[batch_idx, beam_indices, token_indices]
            token_embeddings = token_emb(current_tokens)

            selected_hd = self.transition[step_idx](token_embeddings.reshape(-1,self.hidden_size).bfloat16(),selected_hd.reshape(-1,self.hidden_size).bfloat16()).reshape(B,k,self.hidden_size)
            new_hd = selected_hd
        else:
            new_hd = beam_data['hd']  # 最后一步不需要更新
        return {
            'hd': new_hd,
            'logits': selected_logits,
            'hd_origin': beam_data['hd_origin'],
            'sequences': new_sequences}




def mtp_generate(self,
    input_ids: torch.LongTensor = None,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_values: Optional[Union[Cache, List[torch.FloatTensor]]] = None,
    inputs_embeds: Optional[torch.FloatTensor] = None,
    labels: Optional[torch.LongTensor] = None,
    use_cache: Optional[bool] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    return_dict: Optional[bool] = None,
    # cache_position: Optional[torch.LongTensor] = None,
    logits_to_keep: int = 0,
    topk=512 
    # **kwargs
): # Inference 
    output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
    output_hidden_states = (
        output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
    )
    return_dict = return_dict if return_dict is not None else self.config.use_return_dict

    # decoder outputs consists of (dec_features, layer_state, dec_hidden, dec_attn)
    outputs = self.model(
        input_ids=input_ids,
        attention_mask=attention_mask,
        position_ids=position_ids,
        past_key_values=past_key_values,
        inputs_embeds=inputs_embeds,
        use_cache=use_cache,
        output_attentions=output_attentions,
        output_hidden_states=output_hidden_states,
        return_dict=return_dict,
        # cache_position=cache_position,
        # **kwargs,
    )

    hidden_states = outputs[0]
    return self.mtp_head.predict(hidden_states[:,-2-len(self.config.docid_num):-1],topk)


def ctr_forward(
    self,
    input_ids: torch.LongTensor = None,
    attention_mask: Optional[torch.Tensor] = None,
    position_ids: Optional[torch.LongTensor] = None,
    past_key_values: Optional[Union[Cache, List[torch.FloatTensor]]] = None,
    inputs_embeds: Optional[torch.FloatTensor] = None,
    labels: Optional[torch.LongTensor] = None,
    use_cache: Optional[bool] = None,
    output_attentions: Optional[bool] = None,
    output_hidden_states: Optional[bool] = None,
    return_dict: Optional[bool] = None,
    # cache_position: Optional[torch.LongTensor] = None,
    logits_to_keep: Union[int, torch.Tensor] = 0,
    # **kwargs
) -> Union[Tuple, CausalLMOutputWithPast]: # Training forward 
    outputs: BaseModelOutputWithPast = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            # cache_position=cache_position,
            # **kwargs,
        )
    hidden_states = outputs[0]
    # Only compute necessary logits, and do not upcast them to float if we are not computing the loss
    # logits = self.lm_head(hidden_states[:, -logits_to_keep:, :]) # LM logits
    loss = None
    if labels is not None:
        batch = input_ids.shape[0] # B, N
        sequence_lengths = torch.eq(input_ids, self.config.pad_token_id).int().argmax(-1) - 1
        sequence_lengths = sequence_lengths % input_ids.shape[-1] + 1
        row = (sequence_lengths - len(self.config.docid_num) - 1).unsqueeze(1)
        indices = row + torch.arange(len(self.config.docid_num)+1, device=row.device).unsqueeze(0)
        batch_indices = torch.arange(batch).view(batch, 1).expand(-1, len(self.config.docid_num)+1)
        partial_hd = hidden_states[batch_indices,indices,:] 
        subspace_labels = labels[batch_indices[:,1:],indices[:,1:]]-torch.tensor(self.config.offset,device=labels.device)[None,:]
        flatten_labels =  labels[batch_indices[:,1:],indices[:,1:]].reshape([batch,-1]) # B,3*N
        mtp_logits = self.mtp_head(partial_hd,subspace_labels) # B,3*N,Voc  # [[B,N,S1],[B,N,S2],[B,N,S3]]
        full_logits = self.mtp_head.return_logits(mtp_logits)
        ntp_loss = fixed_cross_entropy(source=full_logits.view(-1, self.config.vocab_size), target=flatten_labels.view(-1))# 
        print(json.dumps({
            "ntp_loss":ntp_loss.item(),
            }))
    return CausalLMOutputWithPast(
            loss=ntp_loss,
            logits=full_logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )